https://www.topcoder.com/thrive/articles/basic-api-using-django-rest-framework?utm_source=thrive&utm_campaign=thrive-feed&utm_medium=rss-feed

https://blog.logrocket.com/django-rest-framework-create-api/

